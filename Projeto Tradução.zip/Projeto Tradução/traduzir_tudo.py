import os
import ollama

# --- CONFIGURAÇÃO DE PASTAS ---
# Ajuste estes nomes para as pastas que você criou no seu PC
input_folder = "./2_Selecionados"  # Pasta com os arquivos que passaram na limpeza
output_folder = "./3_Traduzidos"   # Pasta onde os traduzidos serão salvos

if not os.path.exists(output_folder):
    os.makedirs(output_folder)

prompt_sistema = """# ROLE
You are a Senior Game Localizer adapting a game into Brazilian Portuguese (pt-BR).

# TASK
Rewrite the provided data structure, translating ONLY the English text that is intended to be seen by the player.

# TECHNICAL STRICTNESS
- Return the ENTIRE file perfectly reconstructed.
- Preserve all structural syntax (quotes, brackets, commas).
- Preserve all rich text tags (<b>, <color>) and code variables ({0}, %s, \n) exactly as they appear.

# OUTPUT
Provide ONLY the raw localized code block. No conversational text. No markdown formatting like ```json."""

# --- LOOP DE TRADUÇÃO ---
for nome_arquivo in os.listdir(input_folder):
    if nome_arquivo.endswith(".json") or nome_arquivo.endswith(".txt"):
        caminho_in = os.path.join(input_folder, nome_arquivo)
        caminho_out = os.path.join(output_folder, nome_arquivo)
        
        with open(caminho_in, 'r', encoding='utf-8') as f:
            codigo_original = f.read()

        print(f"Traduzindo: {nome_arquivo}...")
        
        try:
            # Chama o Ollama
            response = ollama.generate(
                model='deepseek-v3.1:671b-cloud', # Verifique se este nome está IGUAL no seu Ollama
                system=prompt_sistema,
                prompt=f"{codigo_original}"
            )

            # Pega o texto da resposta
            texto_final = response['response']

            # LIMPEZA: Remove possíveis blocos de Markdown que a IA pode colocar
            texto_final = texto_final.replace('```json', '').replace('```cpp', '').replace('```', '').strip()

            # Salva o arquivo traduzido e limpo
            with open(caminho_out, 'w', encoding='utf-8') as f:
                f.write(texto_final)
                
        except Exception as e:
            print(f"ERRO ao traduzir {nome_arquivo}: {e}")

print("\n--- PROCESSO FINALIZADO COM SUCESSO! ---")