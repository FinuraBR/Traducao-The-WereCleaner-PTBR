import os
import re
import shutil

# --- CONFIGURAÇÃO DE CAMINHOS ---
caminho_do_projeto = os.path.dirname(os.path.abspath(__file__))
pasta_origem = os.path.join(caminho_do_projeto, "1_Dump_Temporario")
pasta_destino = os.path.join(caminho_do_projeto, "2_Selecionados")

# Cria a pasta de destino se ela não existir
if not os.path.exists(pasta_destino):
    os.makedirs(pasta_destino)

# --- LISTA DE OURO (Whitelist) ---
# Apenas arquivos contendo estas chaves serão movidos
CHAVES_UTEIS = [
    "m_text", "m_placeholder", "m_captiontext", # UI Principal
    "name", "displayname", "m_title", "title",  # Nomes
    "description", "m_description", "collectibledescription", # Descrições
    "m_label", "label", "m_tooltip", "tooltip", # Rótulos
    "m_message", "message", "m_dialogue", "dialogue", # Falas
    "content", "objective", "subtitle", "hint", # Narrativa
    "largetext", "smalltext", "details", "state" # Discord/Steam
]

# Valores técnicos que devemos ignorar mesmo se a chave for válida
VALORES_IGNORAR = ["GameObject", "MonoBehaviour", "Default", "", "Untagged"]

print(f"--- Iniciando Seleção baseada em Regex ---")
print(f"Origem: {pasta_origem}")
print(f"Destino: {pasta_destino}")

if not os.path.exists(pasta_origem):
    print(f"ERRO: A pasta '1_Dump_Temporario' não foi encontrada!")
else:
    movidos = 0
    ignorados = 0

    for arquivo in os.listdir(pasta_origem):
        # Processa apenas .txt e .json
        if arquivo.endswith(".txt") or arquivo.endswith(".json"):
            caminho_origem = os.path.join(pasta_origem, arquivo)
            
            try:
                with open(caminho_origem, 'r', encoding='utf-8', errors='ignore') as f:
                    conteudo = f.read()

                eh_util = False
                
                # Regex que captura chave e valor: "chave": "valor" ou chave = "valor"
                matches = re.finditer(r'("?[\w.\$]+"?)\s*[=:]\s*"([^"]*)"', conteudo)
                
                for match in matches:
                    # Limpa a chave (tira aspas e espaços e põe em minúsculo)
                    chave = match.group(1).lower().replace('"', '').strip()
                    valor = match.group(2)

                    # --- O FILTRO DE OURO ---
                    # 1. A chave precisa estar na lista
                    # 2. A chave NÃO pode ser m_name (mesmo contendo 'name')
                    if chave in CHAVES_UTEIS and chave != "m_name":
                        
                        # 3. O valor não pode ser lixo técnico (ex: "GameObject")
                        if valor not in VALORES_IGNORAR:
                            
                            # Se passou por tudo isso, achamos TEXTO DE JOGO!
                            eh_util = True
                            break # Para de ler o arquivo e já move ele

                if eh_util:
                    caminho_destino = os.path.join(pasta_destino, arquivo)
                    shutil.move(caminho_origem, caminho_destino)
                    print(f"[+] MOVIDO (Útil): {arquivo}")
                    movidos += 1
                else:
                    # Se não achou nada útil, deixa lá quieto
                    ignorados += 1
            
            except Exception as e:
                print(f"Erro ao ler {arquivo}: {e}")

    print("-" * 40)
    print(f"SELEÇÃO CONCLUÍDA!")
    print(f"Arquivos com texto MOVIDOS para '2_Selecionados': {movidos}")
    print(f"Arquivos técnicos deixados em '1_Dump_Temporario': {ignorados}")